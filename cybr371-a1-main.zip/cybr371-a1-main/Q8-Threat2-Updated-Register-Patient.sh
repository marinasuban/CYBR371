#!/bin/bash

# Prompt the doctor for patient information
echo "Enter the following information about the patient:"
read -p "First name: " firstName
read -p "Last name: " lastName
read -p "Year of birth: " yearOfBirth
read -p "Phone number: " phoneNumber
read -p "Email: " email
read -p "Doctor(s) (~primaryDoctor,#assignedDoctor(s)...): " doctors

# Get Assigned Doctor
if [[ $doctors == *","* ]]; then
  assignedDoctor=$(echo $doctors | cut -d "," -f 2-)
else
  assignedDoctor=""
fi

# Create a patient file with the entered information
echo "Creating patient file..."
patientsmedication_filename="/opt/WellingtonClinic/PatientMedication/${firstName}${lastName}${yearOfBirth}medication.txt"
patients_filename="/opt/WellingtonClinic/Patients/${firstName}${lastName}${yearOfBirth}.txt"

# Add patient information to file in desired format
echo -n "$firstName,$lastName,$yearOfBirth,$phoneNumber,$email,$doctors" > "$patients_filename"
echo -n "$firstName,$lastName,$doctors" > "$patientsmedication_filename"

# Set Patient File Permission
chmod 600 "$patients_filename"
setfacl -m g:sudo:rwx "$patients_filename"

# Set Patient Medication File Permission
chmod 200 "$patientsmedication_filename"
setfacl -m g:sudo:rwx "$patientsmedication_filename"
setfacl -m g:Nurse:r-- "$patientsmedication_filename"

# Set Assigned Doctor File Permission
if [[ ! -z "$assignedDoctor" ]]; then
  extracted_Assigned_Doctor=$(echo "$assignedDoctor" | sed 's/#//g' | tr ',' ' ')
  for AD_Username in $extracted_Assigned_Doctor
  do
    setfacl -m u:"$AD_Username":rw- "$patients_filename"
    setfacl -m u:"$AD_Username":-w- "$patientsmedication_filename"
  done
fi

getfacl "$patientsmedication_filename"
getfacl "$patients_filename"
echo "$patientsmedication_filename created successfully!"
echo "$patients_filename created successfully!"
