#!/bin/bash

# Prompt the doctor for patient information
echo "Enter the following information about the patient:"
read -p "First name: " firstName
read -p "Last name: " lastName
read -p "Year of birth: " yearOfBirth
read -p "Phone number: " phoneNumber
read -p "Email: " email
read -p "Doctor(s) (~primaryDoctor,#assignedDoctor(s)...): " doctors

# Get Assigned Doctor
if [[ $doctors == *","* ]]; then
  assignedDoctor=$(echo $doctors | cut -d "," -f 2-)
else
  assignedDoctor=""
fi

# Create a patient file with the entered information
echo "Creating patient file..."
cd /opt/WellingtonClinic/Patients
filename="${firstName}${lastName}${yearOfBirth}.txt"

# Add patient information to file in desired format
echo -n "$firstName,$lastName,$yearOfBirth,$phoneNumber,$email,$doctors" > "$filename"

# Set General Patient File Permission
chmod 600 /opt/WellingtonClinic/Patients/"$filename"
setfacl -m g:sudo:rwx /opt/WellingtonClinic/Patients/"$filename"
setfacl -m g:Nurse:r-- /opt/WellingtonClinic/Patients/"$filename"

# Set Assigned Doctor Permission
if [[ ! -z "$assignedDoctor" ]]; then
  extracted_Assigned_Doctor=$(echo "$assignedDoctor" | sed 's/#//g' | tr ',' ' ')
  for AD_Username in $extracted_Assigned_Doctor
  do
    setfacl -m u:"$AD_Username":rw- /opt/WellingtonClinic/Patients/"$filename"
  done
fi

getfacl /opt/WellingtonClinic/Patients/"$filename"
echo "$filename created successfully!"
