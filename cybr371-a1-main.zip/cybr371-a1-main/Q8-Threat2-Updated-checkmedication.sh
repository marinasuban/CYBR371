#!/bin/bash
read -p "Enter patient's first name: " first_name
read -p "Enter patient's last name: " last_name
read -p "Enter patient's year of birth: " year_of_birth

# Get patient file name
file="/opt/WellingtonClinic/PatientMedication/${first_name}${last_name}${year_of_birth}medication.txt"

# Check if patient file exists
if [[ ! -f "$file" ]]; then
  echo "Patient file not found."
  exit 1
fi

# Get primary doctor
primary_doctor=$(head -n 1 $file | cut -d ',' -f 3 | tr -d '~')
# Get assigned doctors
assigned_doctors=$(head -n 1 $file | cut -d ',' -f 4 | tr -d '#')

# Print header
echo "Patient   Primary Doctor  Assigned Doctor(s)"
echo "${first_name} ${last_name}    ${primary_doctor}   ${assigned_doctors}"

# Print medication information
echo ""
echo "Date of Visit Attended Doctor Medication Dosage"
# Read lines from file, skipping the first 1
tail -n +2 "$file"
