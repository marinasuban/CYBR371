#!/bin/bash

# Check if the script is being run by an administrator
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as an administrator" 
   exit 1
fi

# Create directory structure
mkdir -p /opt/WellingtonClinic/Patients

# Create administrator account
useradd -g sudo -m -s /bin/bash BenM
echo 'BenM:admin123' | chpasswd
id BenM

# Create doctor accounts
groupadd Doctor

useradd -g Doctor -m -s /bin/bash DrMaryT
echo 'DrMaryT:asdf123' | chpasswd
id DrMaryT

useradd -g Doctor -m -s /bin/bash DrMandyS
echo 'DrMandyS:asdf123' | chpasswd
id DrMandyS

useradd -g Doctor -m -s /bin/bash DrEliM
echo 'DrEliM:asdf123' | chpasswd
id DrEliM

# Create nurse accounts
groupadd Nurse

useradd -g Nurse -m -s /bin/bash LuciaB
echo 'LuciaB:asdf123' | chpasswd
id LuciaB

useradd -g Nurse -m -s /bin/bash PhilM
echo 'PhilM:asdf123' | chpasswd
id PhilM

# Set File/Directory Permission
# WellingtonClinic
chown BenM:sudo /opt/WellingtonClinic
chmod 070 /opt/WellingtonClinic
setfacl -m g:Doctor:--x /opt/WellingtonClinic
setfacl -m g:Nurse:--x /opt/WellingtonClinic
getfacl /opt/WellingtonClinic

# Patient
chown BenM:sudo /opt/WellingtonClinic/Patients
chmod 070 /opt/WellingtonClinic/Patients
setfacl -m g:Doctor:rwx /opt/WellingtonClinic/Patients
setfacl -m g:Nurse:--x /opt/WellingtonClinic/Patients
getfacl /opt/WellingtonClinic/Patients
