#!/bin/bash

# Check user is root
if [ "$EUID" -ne 0 ]; then
    echo "Must be run as root" >&2
    exit 1
fi

# Install and start auditd service
sudo apt install auditd 2> /dev/null
sudo service auditd start

# Configure auditd service to track modifications to WellingtonClinic
sudo auditctl -w /opt/WellingtonClinic -p wax -k modifications 2> /dev/null

# Append audit rules to /etc/audit/rules.d/my.rules and restart auditd service
echo "-D" > /etc/audit/rules.d/my.rules 
auditctl -l >> /etc/audit/rules.d/my.rules 
sudo service auditd restart 

# Display audit logs formatted as Username Object Operation Date
echo "=========================================="
sudo ausearch -k modifications | aureport -f -i | awk 'BEGIN {print "Username Object Operation Date"} NR>5 {print $8,$4,$5,$2}'
