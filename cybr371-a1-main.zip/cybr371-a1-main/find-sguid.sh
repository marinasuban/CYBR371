#!/bin/bash

# Get the user's home directory
user_home_dir=$(eval echo ~$1)

# Check if the user's home directory exists
if [ ! -d "$user_home_dir" ]; then
  echo "Error: User home directory not found."
  exit 1
fi

# Function to calculate octal representation of permissions
get_octal_permission() {
  # Create variables
  local perm=$1
  local octal_perm=""
  local user_permission="${perm:1:3}"
  local group_permission="${perm:4:3}"
  local other_permission="${perm:7:3}"
  local special_permission_octal=0
  local user_permission_octal=0
  local group_permission_octal=0
  local other_permission_octal=0
  
  # Calculates user permissions
  if [[ $user_permission == *[S]* ]]; then
  special_permission_octal=$((special_permission_octal + 4))
  fi;
  if [[ $user_permission == *[s]* ]]; then
  special_permission_octal=$((special_permission_octal + 4))
  user_permission_octal=$((user_permission_octal + 1))
  fi;
  if [[ $user_permission == *[r]* ]]; then
  user_permission_octal=$((user_permission_octal + 4))
  fi;
  if [[ $user_permission == *[w]* ]]; then
  user_permission_octal=$((user_permission_octal + 2))
  fi;
  if [[ $user_permission == *[x]* ]]; then
  user_permission_octal=$((user_permission_octal + 1))
  fi;

  # Calculates group permission
  if [[ $group_permission == *[S]* ]]; then
  special_permission_octal=$((special_permission_octal + 2))
  fi;
  if [[ $group_permission == *[s]* ]]; then
  special_permission_octal=$((special_permission_octal + 2))
  group_permission_octal=$((group_permission_octal + 1))
  fi;
  if [[ $group_permission == *[r]* ]]; then
  group_permission_octal=$((group_permission_octal + 4))
  fi;
  if [[ $group_permission == *[w]* ]]; then
  group_permission_octal=$((group_permission_octal + 2))
  fi;
  if [[ $group_permission == *[x]* ]]; then
  group_permission_octal=$((group_permission_octal + 1))
  fi;
  
  # Calculates other permission
  if [[ $other_permission == *[T]* ]]; then
  special_permission_octal=$((special_permission_octal + 1))
  fi;
  if [[ $other_permission == *[t]* ]]; then
  special_permission_octal=$((special_permission_octal + 1))
  other_permission_octal=$((other_permission_octal + 1))
  fi;
  if [[ $other_permission == *[r]* ]]; then
  other_permission_octal=$((other_permission_octal + 4))
  fi;
  if [[ $other_permission == *[w]* ]]; then
  other_permission_octal=$((other_permission_octal + 2))
  fi;
  if [[ $other_permission == *[x]* ]]; then
  other_permission_octal=$((other_permission_octal + 1))
  fi;
  
  # Set octal permission value
  octal_perm="$special_permission_octal$user_permission_octal$group_permission_octal$other_permission_octal"
  echo "$octal_perm"
}

echo "File or directory | Type | Permission | Permission/Octal | Note"
echo "-----------------------------------------------------------------"

# Recursively search user's home directory and list files and directories
find "$user_home_dir" -type f -o -type d | while read -r entry; do
  # Determine if entry is a file or a directory
  if [ -d "$entry" ]; then
    type="Directory"
    permissions=$(stat -c "%A" "$entry")
  else
    type="File"
    permissions=$(stat -c "%A" "$entry")
  fi

  # Get octal representation of permissions
  octal_permissions=$(get_octal_permission "$permissions")

  # Check if file has SUID and/or SGID or sticky bit set
  if [[ $permissions == *"s"* || $permissions == *"S"* || $permissions == *"t"* ]]; then
    note="*suspicious"
  else
    note="-"
  fi

  # Print the file or directory details
  echo "$entry | $type | $permissions | $octal_permissions | $note"
done
