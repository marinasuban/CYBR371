#!/bin/bash

read -p "Enter the username: " username

# Get user information
userinfo=$(getent passwd "$username")

if [[ -z $userinfo ]]; then
  echo "User not found."
  exit 1
fi

# Extract information from user information
userid=$(echo "$userinfo" | cut -d: -f3)
groupids=$(echo "$userinfo" | cut -d: -f4)
groupnames=$(id -Gn "$username" | tr ' ' ', ')
home=$(echo "$userinfo" | cut -d: -f6)

# Check if shadow file exists
if [ -e "/etc/shadow" ]; then
  # Check if the user has a password entry in the shadow file
  if grep -q "^$username:" /etc/shadow; then
    shadow_exists="Yes"
    hash=$(grep "^$username:" /etc/shadow | cut -d: -f2 | cut -d'$' -f2)
    last_change=$(grep "^$username:" /etc/shadow | cut -d: -f3)
  else
    shadow_exists="No"
  fi
else
  shadow_exists="No"
fi

# Map most common hash algorithm
if [ "$hash" == "6" ]; then
    hash=SHA-512
elif [ "$hash" == "5" ]; then
    hash=SHA-256
elif [ "$hash" == "2a" ]; then
    hash=Blowfish
elif [ "$hash" == "1" ]; then
    hash=MD5
fi

# Print user information
echo "Username: $username"
echo "Groups: $groupnames"
echo "UserID: $userid"
echo "Group(s) ID: $groupids"
echo "Home Directory: $home"
echo "Shadow file?: $shadow_exists"
if [[ $shadow_exists == "Yes" ]]; then
  echo "Hashing Algorithm Used? $hash"
  echo "Date of last password change: $(date -d "1970-01-01 +$last_change days" +"%d/%m/%Y")"
fi
