#!/bin/bash

# Get the username
doctor=$(whoami)

# declare list of patient name
patientsName=()

# Search for all patient records that contain the doctor's name and are readable by the doctor
files=$(find /opt/WellingtonClinic/Patients -maxdepth 1 -type f -readable -name "*.txt" -exec grep -l "$doctor" {} \;)

# print findings
echo "Doctor Patients"

# If no patient records were found return 
if [ -z "$files" ]; then
    echo "${doctor} -"
else
    # Extract the names of the patients from the patient records and display them
    for file in $files; do
    patients=$(head -n 1 $file | grep -o '^[^,]*,[^,]*' | sed 's/,/ /')
    patientsName+=("$patients,")
    done
    #print patients 
    echo $(echo $doctor ${patientsName[@]} | sed 's/,$//')
fi
