#!/bin/bash

# Prompt the user for patient information
read -p "Enter patient first name: " firstname
read -p "Enter patient last name: " lastname
read -p "Enter patient year of birth: " dob
read -p "Enter date of appointment (yyyy-mm-dd): " appt
read -p "Is the primary doctor available for the appointment? (yes/no): " available

# set filepath
filepath="/opt/WellingtonClinic/Patients/${firstname}${lastname}${dob}.txt"

# Check if the patient file exists
if [ ! -f "$filepath" ]; then
  echo "Error: patient file not found"
  exit 1
fi

# Check if the user is file owner
owner=$(stat -c '%U' "$filepath")
if [ $(whoami) != "$owner" ]; then
  echo "Error: must be ran by primary doctor"
  exit 1
fi

# Check if the doctor is not available
if [ "$available" = "no" ]; then
  read -p "Enter assigned doctor username: " doctor
  # Check if the assigned doctor exists
  if ! grep -q "^$doctor:" /etc/passwd; then
    echo "Error: assigned doctor does not exist"
    exit 1
  fi
  # Modify the file permissions and update the assigned doctor field
  setfacl -m u:"$doctor":rw- "$filepath"
  if [[ $(head -n 1 "$filepath") =~ ,$ ]]; then
  sed -i "1s/$/#$doctor/" "$filepath"
  else
  sed -i "1s/$/,$doctor/" "$filepath"
  fi
  getfacl "$filepath"
fi
